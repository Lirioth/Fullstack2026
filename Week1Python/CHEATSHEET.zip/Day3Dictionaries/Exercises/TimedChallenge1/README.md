
# timed challenge #1 — reverse the sentence 🔁📝

Programa simple en **Python** que invierte el orden de las palabras en una oración.

## ▶️ cómo ejecutar
```bash
python timedsentence.py
```
Escribe una línea y presiona **Enter**.

## 🧪 ejemplo
**Entrada**
```
You have entered a wrong domain
```
**Salida**
```
domain wrong a entered have You
```
---

## 👤 Author

**Kevin Cusnir 'Lirioth'**  
Repository: [Fullstack2026](https://github.com/Lirioth/Fullstack2026)  
Week 1 Day 3 - Timed Challenge 1

---

*Happy coding!* 🐍✨